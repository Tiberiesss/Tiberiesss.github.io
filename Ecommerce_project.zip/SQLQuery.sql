-- Create a new database for the e-commerce project
create database ecommerceDB;

-- Switch to the newly created database
use ecommerceDB;

-- Drop the Orders table if it already exists to avoid duplication
drop table if exists dbo.Orders;

-- Create the Orders table with appropriate data types
CREATE TABLE Orders (
    InvoiceNo NVARCHAR(50),
    StockCode NVARCHAR(50),
    Description NVARCHAR(255),
    Quantity int,
    InvoiceDate date,
	InvoiceTime time,
    UnitPrice decimal (10,2),
    CustomerID int,
    Country NVARCHAR(100));

-- Load data into the Orders table from a CSV file
BULK INSERT Orders
FROM 'C:\Users\1\Desktop\�����\��������� ������\DataSets_for_pet_projects\Ecommerce_dataset2.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n',
    CODEPAGE = '65001',
    TABLOCK);

	-- Remove any records with NULL values to ensure data consistency
DELETE FROM Orders
WHERE InvoiceNo IS NULL
   OR StockCode IS NULL
   OR Description IS NULL
   OR Quantity IS NULL
   OR InvoiceDate IS NULL
   OR InvoiceTime IS NULL
   OR UnitPrice IS NULL
   OR CustomerID IS NULL
   OR Country IS NULL;

-- Create a view to classify transactions as purchases or returns and calculate total price
CREATE VIEW vw_orders_with_type_and_sum AS
SELECT
	InvoiceNo,
	StockCode,
	Description,
	Quantity,
	InvoiceDate,
	InvoiceTime,
	UnitPrice,
	Quantity*UnitPrice AS TotalPrice,
	CustomerID,
	Country,
	CASE
		WHEN Quantity < 0 THEN '�������'
		ELSE '�������'
	END AS TransType
FROM Orders;

-- Create an RFM analysis view to segment customers
CREATE VIEW vw_RFM_analysis AS
SELECT
	CustomerId,
	DATEDIFF(DAY, MAX(CAST(InvoiceDate as DATE)), '2011-12-31') as Recency,
	count(DISTINCT InvoiceNo) as Frequency,
	sum(TotalPrice) as Monetary
FROM dbo.vw_orders_with_type_and_sum
Group by CustomerID;

-- Create a view to get the top 10 best-selling items
CREATE VIEW vw_Top10_items_sold AS
SELECT Top 10
	Description,
	SUM(Quantity) AS QTY_sold
FROM dbo.vw_orders_with_type_and_sum
WHERE Quantity > 0
GROUP BY Description
ORDER BY QTY_sold DESC;

--Deletted filter
ALTER VIEW vw_Top10_items_sold AS
SELECT Top 10
	Description,
	SUM(Quantity) AS QTY_sold
FROM dbo.vw_orders_with_type_and_sum
GROUP BY Description
ORDER BY QTY_sold DESC;

-- Create a view for monthly revenue analysis
CREATE VIEW vw_monthly_revenue AS
SELECT TOP 22
	FORMAT(CAST(InvoiceDate AS DATE), 'yyyy-MM') AS YearMonth,
	SUM(TotalPrice) AS TotalRevenue
FROM dbo.vw_orders_with_type_and_sum
GROUP BY FORMAT(CAST(InvoiceDate AS DATE), 'yyyy-MM')
ORDER BY YearMonth;

-- Create a view for cumulative revenue analysis
CREATE VIEW vw_cumulative_revenue AS
SELECT TOP 22
	FORMAT(CAST(InvoiceDate AS DATE), 'yyyy-MM') AS YearMonth,
	SUM(TotalPrice) AS MonthlyRevenue,
	SUM(SUM(TotalPrice)) OVER (ORDER BY FORMAT(CAST(InvoiceDate AS DATE), 'yyyy-MM')) AS CumulativeRevenue
FROM vw_orders_with_type_and_sum
GROUP BY FORMAT(CAST(InvoiceDate AS DATE), 'yyyy-MM')
ORDER BY YearMonth;

-- Create a view to calculate the average order value per customer
CREATE VIEW vw_agv_order_value AS
SELECT
	CustomerID,
	AVG(TotalPrice) AS AvgOrderValue
FROM vw_orders_with_type_and_sum
GROUP BY CustomerID;

ALTER VIEW vw_agv_order_value AS
SELECT
	CustomerID,
	SUM(TotalPrice)/count(distinct CustomerID) AS AvgOrderValue
FROM vw_orders_with_type_and_sum
GROUP BY CustomerID;

-- Create a view to analyze customer retention
CREATE VIEW vw_retention_rate AS
SELECT
	CustomerID,
	Count(DISTINCT InvoiceNo) AS TotalOrders,
	CASE 
		WHEN COUNT(DISTINCT InvoiceNo) > 1 
		THEN 'Returning Customer' 
		ELSE 'One-time Customer' 
		END 
			AS CustomerType
FROM vw_orders_with_type_and_sum
GROUP BY CustomerID;

-- Create a view to analyze peak purchase hours
CREATE VIEW vw_peak_hours AS
SELECT TOP 16
	DATEPART(HOUR, CAST(InvoiceTime AS TIME)) AS PurchaseHour,
	COUNT(*) AS TotalOrders
FROM vw_orders_with_type_and_sum
GROUP BY DATEPART(HOUR, CAST(InvoiceTime AS TIME))
ORDER BY PurchaseHour;

ALTER VIEW vw_peak_hours AS
WITH RankedHours AS (
    SELECT 
        ROW_NUMBER() OVER (ORDER BY MIN(DATEPART(HOUR, InvoiceTime))) AS RowNum,
        CASE 
            WHEN DATEPART(HOUR, InvoiceTime) = 0 THEN '12AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 1 THEN '1AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 2 THEN '2AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 3 THEN '3AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 4 THEN '4AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 5 THEN '5AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 6 THEN '6AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 7 THEN '7AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 8 THEN '8AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 9 THEN '9AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 10 THEN '10AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 11 THEN '11AM'
            WHEN DATEPART(HOUR, InvoiceTime) = 12 THEN '12PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 13 THEN '1PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 14 THEN '2PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 15 THEN '3PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 16 THEN '4PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 17 THEN '5PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 18 THEN '6PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 19 THEN '7PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 20 THEN '8PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 21 THEN '9PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 22 THEN '10PM'
            WHEN DATEPART(HOUR, InvoiceTime) = 23 THEN '11PM'
        END AS PurchaseHour,
        COUNT(*) AS TotalOrders
    FROM vw_orders_with_type_and_sum
    GROUP BY DATEPART(HOUR, InvoiceTime)
)
SELECT TOP 16 *
FROM RankedHours
ORDER BY RowNum;


-- Create a view to analyze revenue by country
CREATE VIEW vw_revenue_by_country AS
SELECT TOP 50
	Country,
	ROUND(SUM(TotalPrice), 0) AS TotalRevenue
FROM vw_orders_with_type_and_sum
GROUP BY Country
ORDER BY TotalRevenue DESC;

-- Create a view to analyze returns percentage
CREATE VIEW vw_returns_analysis AS
SELECT
	TransType,
	COUNT(InvoiceNo) AS TOtalOrders,
	CAST(COUNT(InvoiceNo) * 100 / SUM(COUNT(InvoiceNo)) OVER() AS DECIMAL(10,0)) AS 'Rate %'
FROM vw_orders_with_type_and_sum
GROUP BY TransType;

-- Create a view to calculate RFM scores for each customer
CREATE VIEW vw_RFM_clusters AS
SELECT
	CustomerID,
	Recency,
	Frequency,
	Monetary,
	NTILE(4) OVER (ORDER BY Recency DESC) AS R_Score,
	NTILE(4) OVER (ORDER BY Frequency) AS F_Score,
	NTILE(4) OVER (ORDER BY Monetary) AS M_Score
FROM vw_RFM_analysis;

-- Create a view to generate final RFM segments based on the calculated scores
CREATE VIEW vw_RFM_final AS
SELECT
	*,
	CAST(R_Score AS VARCHAR) + CAST(F_Score AS VARCHAR) + CAST(M_Score AS VARCHAR) AS RFM_Score,
	CASE 
		WHEN (R_Score = 4 AND F_Score >= 3 AND M_Score >= 3) THEN 'Best Customers'
		WHEN (R_Score >= 3 AND F_Score >= 3) THEN 'Loyal Customers'
		WHEN (R_Score <= 2 AND F_Score <= 2 AND M_Score <= 2) THEN 'At Risk Customers'
		WHEN (R_Score = 1 AND F_Score = 2 AND M_Score = 3) THEN 'New Customers'
		ELSE 'Other'
	END AS RFM_Cluster
FROM vw_RFM_clusters;

-- changed the clusters to shorter name
ALTER VIEW vw_RFM_final AS
SELECT
	*,
	CAST(R_Score AS VARCHAR) + CAST(F_Score AS VARCHAR) + CAST(M_Score AS VARCHAR) AS RFM_Score,
	CASE 
		WHEN (R_Score = 4 AND F_Score >= 3 AND M_Score >= 3) THEN 'Best'
		WHEN (R_Score >= 3 AND F_Score >= 3) THEN 'Loyal'
		WHEN (R_Score <= 2 AND F_Score <= 2 AND M_Score <= 2) THEN 'At Risk'
		WHEN (R_Score = 1 AND F_Score = 2 AND M_Score = 3) THEN 'New'
		ELSE 'Other'
	END AS RFM_Cluster
FROM vw_RFM_clusters
WHERE Monetary > 0;